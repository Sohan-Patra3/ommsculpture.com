-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 31, 2020 at 04:00 AM
-- Server version: 5.6.49-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vikash_dynamic`
--

-- --------------------------------------------------------

--
-- Table structure for table `adv_banner`
--

CREATE TABLE `adv_banner` (
  `id` int(11) NOT NULL,
  `image` varchar(150) NOT NULL,
  `height` int(11) NOT NULL,
  `cancel` int(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adv_banner`
--

INSERT INTO `adv_banner` (`id`, `image`, `height`, `cancel`, `status`) VALUES
(5, 'group-418636_1920-1598686136.jpg', 150, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `banner_mst`
--

CREATE TABLE `banner_mst` (
  `BAM_BACD` int(11) NOT NULL,
  `BAM_ORCD` int(1) NOT NULL,
  `BAM_ORD` int(1) NOT NULL,
  `BAM_IMG` varchar(255) NOT NULL,
  `BAM_CANC` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banner_mst`
--

INSERT INTO `banner_mst` (`BAM_BACD`, `BAM_ORCD`, `BAM_ORD`, `BAM_IMG`, `BAM_CANC`) VALUES
(5, 1, 3, '42-420058_nature-wallpapers-full-screen-hd-images-of-nature.-1572607875.jpg', 0),
(6, 1, 2, 'ee283bc2a859497e5af0f172d85fa79e-1572607889.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `category_mst`
--

CREATE TABLE `category_mst` (
  `category_id` int(11) NOT NULL,
  `orcd` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category_mst`
--

INSERT INTO `category_mst` (`category_id`, `orcd`, `name`, `image`, `description`, `status`) VALUES
(1, 1, 'Machinery', 'VC logo Image11.jpg', '<p>It&#39;s use for different uses on food production</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cat_mst01`
--

CREATE TABLE `cat_mst01` (
  `CAM_CACD` int(10) NOT NULL,
  `CAM_CANM` varchar(60) NOT NULL,
  `CAM_ORCD` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cat_mst01`
--

INSERT INTO `cat_mst01` (`CAM_CACD`, `CAM_CANM`, `CAM_ORCD`) VALUES
(1, 'Annual function', 1),
(2, 'Pump', 1),
(3, 'Pipe and Fittings', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `subject`, `message`, `date_time`) VALUES
(2, 'AnilPatra', 'vikashcorporation@gmail.com', '8457952586', 'ProductRequred', 'hallowsirgoodmorning', '2020-01-19 13:29:24'),
(3, 'niranjan puthal', 'divyasundarsahu@gmail.com', '9348504341', 'Testing2', 'Tight pants next level keffiyeh you probably haven\'t heard of them. Photo booth beard raw denim letterpress vegan messenger bag Stumptown. Farm-to-table seitan.', '2020-01-22 10:25:11'),
(4, 'Myles Louis', 'myles.louis@outlook.com', '478 1427', 'myles.louis@outlook.com', 'Do you want to post your advertisement on thousands of advertising sites monthly? One tiny investment every month will get you almost unlimited traffic to your site forever!\r\n\r\nGet more info by visiting: http://bit.ly/adpostingrobot', '2020-04-11 21:16:11'),
(5, 'Janina Thibeault', 'janina.thibeault@outlook.com', '01.51.21.90.28', 'janina.thibeault@outlook.com', 'Do you want to post your advertisement on thousands of advertising sites monthly? Pay one low monthly fee and get virtually unlimited traffic to your site forever!\r\n\r\nFor details check out: http://www.adpostingrobot.xyz', '2020-05-08 08:16:56'),
(6, 'Floy Soria', 'soria.floy@gmail.com', '0343 3215789', 'soria.floy@gmail.com', 'Would you like to promote your advertisement on thousands of online ad websites every month? One tiny investment every month will get you almost endless traffic to your site forever!\r\n\r\nFor more information just visit: https://bit.ly/adpostingfast', '2020-05-31 07:05:37'),
(7, 'Dwight Neblett', 'neblett.dwight@gmail.com', '734-451-6685', 'neblett.dwight@gmail.com', '\r\nQuit paying way too much money for overpriced online ads! I have a system that requires only a tiny bit of money and creates an almost indefinite amount of web visitors to your website\r\n\r\nCheck out our site now: http://www.auto-ad-posting.xyz', '2020-06-27 06:56:08'),
(8, 'Anil Sahoo', 'vikashcorporation@gmail.com', '8457952586', 'Dealership', 'Can you give me our district on your product for dealership', '2020-08-15 10:32:26'),
(9, 'Eric Jones', 'eric@talkwithwebvisitor.com', '416-385-3200', 'Strike when the ironâ€™s hot', 'Hey there, I just found your site, quick questionâ€¦\r\n\r\nMy nameâ€™s Eric, I found vikashcorporation.com after doing a quick search â€“ you showed up near the top of the rankings, so whatever youâ€™re doing for SEO, looks like itâ€™s working well.\r\n\r\nSo he', '2020-08-16 10:54:06'),
(10, 'Traci Adair', 'adair.traci@googlemail.com', '707-637-7761', 'You Have Been Called Upon', 'Hello, I have been informed to contact you. The CIA has been doing intensive research for the past fifty years researching on what we call so called life. That information has been collected and presented for you here https://bit.ly/3lqUJ3u This has been ', '2020-08-29 21:33:34');

-- --------------------------------------------------------

--
-- Table structure for table `gal_dtl01`
--

CREATE TABLE `gal_dtl01` (
  `GAD_GACD` int(11) NOT NULL,
  `GAD_ORCD` int(11) NOT NULL,
  `GAD_CACD` int(11) NOT NULL,
  `GAD_IMG` varchar(60) NOT NULL,
  `GAD_STAT` int(1) NOT NULL,
  `GAD_CANC` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gal_dtl01`
--

INSERT INTO `gal_dtl01` (`GAD_GACD`, `GAD_ORCD`, `GAD_CACD`, `GAD_IMG`, `GAD_STAT`, `GAD_CANC`) VALUES
(1, 1, 1, 'associate-no-jobs-1565264373.png', 1, 0),
(2, 1, 1, 'current-openings-1565264374.png', 1, 0),
(3, 1, 1, 'download---copy-1565264374.jpg', 1, 0),
(4, 1, 2, 'jobs-free-png-image-1565266128.png', 1, 0),
(5, 1, 2, 'unnamed-(1)-1565266128.jpg', 1, 0),
(6, 1, 2, 'unnamed-(2)-1565266128.jpg', 1, 0),
(7, 1, 2, 'associate-no-jobs-1565326509.png', 1, 0),
(8, 1, 3, 'ic-human-resources-operational-functions-1565326509.jpg', 1, 0),
(9, 1, 3, 'untitled-design-5-1569496873.png', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `general_setting`
--

CREATE TABLE `general_setting` (
  `id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `org_id` int(11) NOT NULL,
  `topbar_bgcolor` varchar(10) NOT NULL,
  `topbar_fontsize` varchar(10) NOT NULL,
  `topbar_fontfamily` varchar(50) NOT NULL,
  `topbar_color` varchar(10) NOT NULL,
  `menubar_bgcolor` varchar(10) NOT NULL,
  `menubar_fontsize` varchar(10) NOT NULL,
  `menubar_fontfamily` varchar(50) NOT NULL,
  `menubar_color` varchar(10) NOT NULL,
  `footer_bgcolor` varchar(10) NOT NULL,
  `footer_fontsize` varchar(10) NOT NULL,
  `footer_fontfamily` varchar(50) NOT NULL,
  `footer_color` varchar(10) NOT NULL,
  `menutitle_fontsize` varchar(10) NOT NULL,
  `menutitle_fontfamily` varchar(50) NOT NULL,
  `menutitle_color` varchar(10) NOT NULL,
  `pagetitle_fontsize` varchar(10) NOT NULL,
  `pagetitle_fontfamily` varchar(50) NOT NULL,
  `pagetitle_color` varchar(10) NOT NULL,
  `pagecontent_fontsize` varchar(10) NOT NULL,
  `pagecontent_fontfamily` varchar(50) NOT NULL,
  `pagecontent_color` varchar(10) NOT NULL,
  `adminmenu_bgcolor` varchar(20) NOT NULL,
  `adminheader_bgcolor` varchar(20) NOT NULL,
  `adminmenu_color` varchar(20) NOT NULL,
  `logo_height` varchar(11) NOT NULL,
  `logo_width` varchar(11) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `ip_address` varchar(20) NOT NULL,
  `sys_name` varchar(160) NOT NULL,
  `date_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general_setting`
--

INSERT INTO `general_setting` (`id`, `page_id`, `org_id`, `topbar_bgcolor`, `topbar_fontsize`, `topbar_fontfamily`, `topbar_color`, `menubar_bgcolor`, `menubar_fontsize`, `menubar_fontfamily`, `menubar_color`, `footer_bgcolor`, `footer_fontsize`, `footer_fontfamily`, `footer_color`, `menutitle_fontsize`, `menutitle_fontfamily`, `menutitle_color`, `pagetitle_fontsize`, `pagetitle_fontfamily`, `pagetitle_color`, `pagecontent_fontsize`, `pagecontent_fontfamily`, `pagecontent_color`, `adminmenu_bgcolor`, `adminheader_bgcolor`, `adminmenu_color`, `logo_height`, `logo_width`, `created_by`, `ip_address`, `sys_name`, `date_time`) VALUES
(2, 13, 1, '#165b02', '15px', '\'Open Sans\', sans-serif', '#94f777', '#ffffff', '14px', '\'Open Sans\', sans-serif', '#000000 ', '#1a1c1d', '14px', '\'Open Sans\', sans-serif', '#ffffff', '20px', '\'Roboto\', sans-serif', '#ff0000', '24px', '\'Roboto\', sans-serif', '#139e81', '', '', '', '#1111ff', '#ffffff', '#ffffff', '45px', '140px', 'Vikash Corporation', '115.42.32.126', 'sg2plcpnl0119.prod.sin2.secureserver.net', '2020-08-31 05:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `org_mst01`
--

CREATE TABLE `org_mst01` (
  `ORM_ORCD` int(10) NOT NULL,
  `ORM_NAME` varchar(60) NOT NULL,
  `ORM_DMNM` varchar(60) NOT NULL,
  `ORM_CPNM` varchar(60) NOT NULL,
  `ORM_MAIL` varchar(60) NOT NULL,
  `ORM_LOGO` varchar(60) NOT NULL,
  `ORM_PROF` varchar(60) NOT NULL,
  `ORM_CONO` varchar(20) NOT NULL,
  `ORM_PASS` varchar(60) NOT NULL,
  `ORM_FB` varchar(255) NOT NULL,
  `ORM_TW` varchar(255) NOT NULL,
  `ORM_YT` varchar(255) NOT NULL,
  `ORM_PT` varchar(255) NOT NULL,
  `ORM_LI` varchar(255) NOT NULL,
  `ORM_GP` varchar(255) NOT NULL,
  `ORM_STAT` int(1) NOT NULL,
  `ORM_CANC` int(1) NOT NULL,
  `ORM_DTTM` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_mst01`
--

INSERT INTO `org_mst01` (`ORM_ORCD`, `ORM_NAME`, `ORM_DMNM`, `ORM_CPNM`, `ORM_MAIL`, `ORM_LOGO`, `ORM_PROF`, `ORM_CONO`, `ORM_PASS`, `ORM_FB`, `ORM_TW`, `ORM_YT`, `ORM_PT`, `ORM_LI`, `ORM_GP`, `ORM_STAT`, `ORM_CANC`, `ORM_DTTM`) VALUES
(1, 'Vikash Corporation', 'www.vikashcorporation.com', 'Anil Patra', 'vikashcorporation@gmail.com', 'onlinelogomaker-082720-2001-4387.png', 'download.png', '9437130468', '12345', 'https://www.facebook.com/?stype=lo&jlou=AfexfBc7SX0BLMn49dIbC8BoEGAwgTzL3I-_FsZPKJbv5dLLDSUUIyGIuQrPcyUybrJu49f2g87RQ4-pwPHAuvsPTgpbDBpxqqFndewG-gdpLw&smuh=26049&lh=Ac8hzzW8r6f0T_Q_', 'https://twitter.com/login?lang=en', 'https://accounts.google.com/signin/v2/identifier?service=youtube&uilel=3&passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3D%252F&hl=en&flowName=GlifWebSignIn&flowEntry=ServiceLogi', 'https://in.pinterest.com/', 'https://in.linkedin.com/', 'https://accounts.google.com/signin/v2/identifier?passive=1209600&continue=https%3A%2F%2Fplay.google.com%2Fstore%2Faccount%3Fhl%3Den&followup=https%3A%2F%2Fplay.google.com%2Fstore%2Faccount%3Fhl%3Den&hl=en&flowName=GlifWebSignIn&flowEntry=ServiceLogin', 1, 0, '2020-08-31 05:18:53');

-- --------------------------------------------------------

--
-- Table structure for table `pag_dtl01`
--

CREATE TABLE `pag_dtl01` (
  `PAD_PGCD` int(10) NOT NULL,
  `PAD_PACD` int(10) NOT NULL,
  `PAD_ORCD` int(10) NOT NULL,
  `PAD_CACD` int(11) NOT NULL,
  `PAD_TITL` varchar(255) NOT NULL,
  `PAD_DESC` varchar(2000) NOT NULL,
  `PAD_IMG` varchar(100) NOT NULL,
  `PAD_API` varchar(60) NOT NULL,
  `PAD_ADSO` varchar(200) NOT NULL,
  `PAD_ADST` varchar(200) NOT NULL,
  `PAD_MAIL` varchar(60) NOT NULL,
  `PAD_PHN` varchar(12) NOT NULL,
  `PAD_LAT` varchar(50) NOT NULL,
  `PAD_LNG` varchar(50) NOT NULL,
  `PAD_STAT` int(1) NOT NULL,
  `PAD_CANC` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pag_dtl01`
--

INSERT INTO `pag_dtl01` (`PAD_PGCD`, `PAD_PACD`, `PAD_ORCD`, `PAD_CACD`, `PAD_TITL`, `PAD_DESC`, `PAD_IMG`, `PAD_API`, `PAD_ADSO`, `PAD_ADST`, `PAD_MAIL`, `PAD_PHN`, `PAD_LAT`, `PAD_LNG`, `PAD_STAT`, `PAD_CANC`) VALUES
(1, 1, 1, 0, 'About Company', '<p><span style=\"color:#c0392b\"><span style=\"font-family:Verdana,Geneva,sans-serif\"><span style=\"font-size:20px\"><strong>Dorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam consectetur sit amet ante nec vulputatery Nullay aliquam, justo auctor consequat tincidunt, arcu erat mattis lorem, lacinia lacinia dui enim at eros. Pellentesque ut gravida augue.</strong></span></span></span></p>\r\n\r\n<p><span style=\"color:#e67e22\"><em><strong>Duis ac dictum tellus Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam consectetur sit amet ante nec vulputate. Nulla aliquam, justo auctor consequat tincidunt, arcu erat mattis lorem, lacinia lacinia dui enim at eros. Pellentesque ut gravida augue.</strong></em></span></p>\r\n\r\n<p><em>Duis ac dictum tellus Pellentesque in mauris placerat, porttitor lorem id, ornare nisl. Pellentesque rhoncus convallis felis, in egestas libero. Donec et nibh dapibus, sodales nisi quis, fringilla augue. Donec dui quam, egestas in varius ut, tincidunt quis ipsum.</em></p>\r\n\r\n<p>Nulla nec odio eu nisi imperdiet dictum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam consectetur sit amet ante nec vulputate. Nulla aliquam, justo auctor consequat tincidunt, arcu erat mattis lorem, lacinia lacinia dui enim at eros. Pellentesque ut gravida augue. Duis ac dictum tellusPellentesque in mauris placerat, porttitor lorem id, ornare nisl. Pellentesque rhoncus convallis felis, in egestas liber Donedapibus.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', 'about-us-1.png', '', '', '', '', '', '', '', 1, 0),
(2, 2, 1, 0, 'Our Company vission', '<h2 style=\"font-style:italic\"><strong><span style=\"color:#000000\"><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Dorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam consectetur sit amet ante nec vulputatery Nullay aliquam, justo auctor consequat tincidunt, arcu erat mattis lorem, lacinia lacinia dui enim at eros. Pellentesque ut gravida augue.</span></span></span></strong></h2>\r\n\r\n<h2 style=\"font-style:italic\"><strong><span style=\"color:#000000\"><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Duis ac dictum tellus Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam consectetur sit amet ante nec vulputate. Nulla aliquam, justo auctor consequat tincidunt, arcu erat mattis lorem, lacinia lacinia dui enim at eros. Pellentesque ut gravida augue.</span></span></span></strong></h2>\r\n\r\n<h2 style=\"font-style:italic\"><strong><span style=\"color:#000000\"><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Duis ac dictum tellus Pellentesque in mauris placerat, porttitor lorem id, ornare nisl. Pellentesque rhoncus convallis felis, in egestas libero. Donec et nibh dapibus, sodales nisi quis, fringilla augue. Donec dui quam, egestas in varius ut, tincidunt quis ipsum.</span></span></span></strong></h2>\r\n\r\n<h2 style=\"font-style:italic\"><strong><span style=\"color:#000000\"><span style=\"font-size:16px\"><span style=\"font-family:Comic Sans MS,cursive\">Nulla nec odio eu nisi imperdiet dictum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam consectetur sit amet ante nec vulputate. Nulla aliquam, justo auctor consequat tincidunt, arcu erat mattis lorem, lacinia lacinia dui enim at eros. Pellentesque ut gravida augue. Duis ac dictum tellusPellentesque in mauris placerat, porttitor lorem id, ornare nisl. Pellentesque rhoncus convallis felis, in egestas liber Donedapibus.</span></span></span></strong></h2>\r\n', '183-1834382_web-development-png.png', '', '', '', '', '', '', '', 1, 0),
(4, 10, 1, 0, 'An Example of a Google Bar Chart lavel', 'www.google.com/', 'S44.doc', '', '', '', '', '', '', '', 1, 0),
(5, 10, 1, 0, 'Mirror Log Scale Example', 'www.google.com', 'html5_tutorial (1).pdf', '', '', '', '', '', '', '', 1, 0),
(6, 10, 1, 0, 'Best web programming tutorials for beginner to advanced', 'programminghubs.com', 'html5_tutorial (1).pdf', '', '', '', '', '', '', '', 1, 0),
(7, 11, 1, 0, 'An Example of a Google Bar Chart ', 'www.google.com/gmail', 'html5_tutorial (1).pdf', '', '', '', '', '', '', '', 1, 0),
(8, 3, 1, 0, 'How can we help?', '', '', 'AIzaSyCw7ZTvYzZwF1HDkHbLC7eckymdbAvjc0k', 'Plot No-2863/3719, Ground Floor, Patra Complex', 'Phulabani, Pin-762001', 'vikashcorporation@gmail.com', ' 9437130468 ', '20.326191', '85.819799', 1, 0),
(9, 9, 1, 1, 'Machinery', '<p>asdfaefsdf jkdsfhjh&nbsp; kjfhdk sd kjdh d h</p>\r\n', 'onlinelogomaker-081520-1425-7894.png', '', '', '', '', '', '', '', 1, 0),
(10, 9, 1, 1, 'Machinery225', '<p>hnbvnbn&nbsp;</p>\r\n', 'cpvc-reducing-brass-tee-500x500.jpg', '', '', '', '', '', '', '', 1, 0),
(11, 9, 1, 1, 'Machinery2254', '<p>dfsdggh</p>\r\n', 'download.jpg', '', '', '', '', '', '', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pag_mst01`
--

CREATE TABLE `pag_mst01` (
  `PAM_PACD` int(10) NOT NULL,
  `PAM_PANM` varchar(60) NOT NULL,
  `PAM_LINK` varchar(20) NOT NULL,
  `PAM_STAT` int(1) NOT NULL,
  `PAM_ORDER` int(1) NOT NULL,
  `PAM_CANC` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pag_mst01`
--

INSERT INTO `pag_mst01` (`PAM_PACD`, `PAM_PANM`, `PAM_LINK`, `PAM_STAT`, `PAM_ORDER`, `PAM_CANC`) VALUES
(1, 'About Us', 'about_us.php', 1, 1, 0),
(2, 'Vision & Mission', 'vision_mission.php', 1, 2, 0),
(3, 'Contact Us', 'contact_us.php', 1, 6, 0),
(5, 'Image Category', 'img_category.php', 2, 0, 0),
(6, 'Image Gallery', 'img_gallery.php', 2, 4, 0),
(9, 'Sub Service', 'services.php', 1, 5, 0),
(10, 'Notice Board', 'noticeboard.php', 0, 0, 0),
(11, 'Latest News', 'latestnews.php', 0, 0, 1),
(12, 'Banner', 'banner.php', 2, 0, 0),
(13, 'General Setting', 'general_setting.php', 0, 0, 0),
(14, 'Service', 'category.php', 1, 3, 0),
(15, 'Menu Setting', 'menu_setting.php', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `phone`, `email`, `password`, `date`) VALUES
(1, 'Admin', '9437130468', 'vikashcorporation@gmail.com', '12345', '2020-08-15 09:13:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adv_banner`
--
ALTER TABLE `adv_banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner_mst`
--
ALTER TABLE `banner_mst`
  ADD PRIMARY KEY (`BAM_BACD`);

--
-- Indexes for table `category_mst`
--
ALTER TABLE `category_mst`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `cat_mst01`
--
ALTER TABLE `cat_mst01`
  ADD PRIMARY KEY (`CAM_CACD`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gal_dtl01`
--
ALTER TABLE `gal_dtl01`
  ADD PRIMARY KEY (`GAD_GACD`);

--
-- Indexes for table `general_setting`
--
ALTER TABLE `general_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `org_mst01`
--
ALTER TABLE `org_mst01`
  ADD PRIMARY KEY (`ORM_ORCD`);

--
-- Indexes for table `pag_dtl01`
--
ALTER TABLE `pag_dtl01`
  ADD PRIMARY KEY (`PAD_PGCD`);

--
-- Indexes for table `pag_mst01`
--
ALTER TABLE `pag_mst01`
  ADD PRIMARY KEY (`PAM_PACD`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adv_banner`
--
ALTER TABLE `adv_banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `banner_mst`
--
ALTER TABLE `banner_mst`
  MODIFY `BAM_BACD` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `category_mst`
--
ALTER TABLE `category_mst`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cat_mst01`
--
ALTER TABLE `cat_mst01`
  MODIFY `CAM_CACD` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `gal_dtl01`
--
ALTER TABLE `gal_dtl01`
  MODIFY `GAD_GACD` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `general_setting`
--
ALTER TABLE `general_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `org_mst01`
--
ALTER TABLE `org_mst01`
  MODIFY `ORM_ORCD` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pag_dtl01`
--
ALTER TABLE `pag_dtl01`
  MODIFY `PAD_PGCD` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pag_mst01`
--
ALTER TABLE `pag_mst01`
  MODIFY `PAM_PACD` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
