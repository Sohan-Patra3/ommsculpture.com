<?php  
include 'includes/header.php';
?>
<div class="container-fluid">
	<div class="row">
		<iframe src="webclone/web-index.php" name="myFrame" style="width:100%; height:1200px;border: none;"></iframe>
	</div>
	</div>
</div>
<?php  include 'includes/footer.php';?>