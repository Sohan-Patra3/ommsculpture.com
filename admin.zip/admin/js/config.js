
CKEDITOR.config.colorButton_enableMore = false;
CKEDITOR.config.colorButton_backStyle = {
    element: 'font',
    styles: { 'background-color': '#(color)' }
};